import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import translations from './translations.json';

// Get language from URL path
const getLanguageFromPath = () => {
  const path = window.location.pathname;
  const match = path.match(/\/([a-z]{2}(?:-[a-z]{2})?)\/?/);
  if (match && translations[match[1] as keyof typeof translations]) {
    return match[1];
  }
  return 'en';
};

i18n
  .use(initReactI18next)
  .init({
    resources: translations,
    lng: getLanguageFromPath(),
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
